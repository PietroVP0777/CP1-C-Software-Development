﻿while (true)
{
    Console.WriteLine("############# Calculadora #############");
    Console.WriteLine("Selecione uma operação: ");
    Console.WriteLine("[1] Adição");
    Console.WriteLine("[2] Subtração");
    Console.WriteLine("[3] Multiplicação ");
    Console.WriteLine("[4] Divisão ");
    Console.WriteLine("[5] Encerrar ");
    Console.WriteLine("");

    int Escolha;
    if (!int.TryParse(Console.ReadLine(), out Escolha))
    {
        Console.WriteLine("Digite um número válido!");
        continue;
    }
    Console.WriteLine("");


    static (int, int) MostrarMenu()
    {
        Console.WriteLine("Digite um número: ");
        int n1 = int.Parse(Console.ReadLine());
        Console.WriteLine("Digite outro número: ");
        int n2 = int.Parse(Console.ReadLine());

        return (n1, n2);
    }




    switch (Escolha)
    {
        case 1:
            {
                var (n1, n2) = MostrarMenu();
                int soma = n1 + n2;
                Console.WriteLine("A soma dos dois números é: " + soma);
                Console.WriteLine("");
                break;
            }

        case 2:
            {
                var (n1, n2) = MostrarMenu();
                int subtracao = n1 - n2;
                Console.WriteLine("A subtração dos dois números é: " + subtracao);
                Console.WriteLine("");
                break;
            }

        case 3:
            {
                var (n1, n2) = MostrarMenu();
                int multiplicacao = n1 * n2;
                Console.WriteLine("A multiplicação dos dois números é: " + multiplicacao);
                Console.WriteLine("");
                break;
            }

        case 4:
            {
                var (n1, n2) = MostrarMenu();
                if (n2 == 0)
                {
                    Console.WriteLine("Não é possivel dividir por 0!");
                    Console.WriteLine("");
                    break;
                }
                else
                {
                    Double divisao = (double)n1 / n2;
                    Console.WriteLine("A divisão dos dois números é: " + divisao);
                    Console.WriteLine("");
                    break;
                }
            }

        case 5:
            {
                Console.WriteLine("Encerrando...");
                return;
            }

        default:
            Console.WriteLine("Opção inválida! Digite um número entre 1 e 5.");
            Console.WriteLine("");
            break;
    }
}